document.getElementById('loadRepos').addEventListener('click', async () => {
  const username = document.getElementById('username').value.trim();
  if (!username) return alert('Enter GitHub username');
  const res = await fetch(`/api/users/${encodeURIComponent(username)}/repos`);
  if (!res.ok) return alert('Error loading repos: ' + res.status);
  const repos = await res.json();
  const container = document.getElementById('repos');
  container.innerHTML = '';
  repos.forEach(r => {
    const div = document.createElement('div');
    div.className = 'repo';
    div.innerHTML = `<div class="meta">
                      <a href="${r.htmlUrl}" target="_blank">${r.fullName}</a>
                      <div class="small">${r.description || ''}</div>
                     </div>
                     <div><button data-repo="${r.name}" data-owner="${r.fullName.split('/')[0]}">Issues</button></div>`;
    const btn = div.querySelector('button');
    btn.addEventListener('click', async () => {
      const owner = btn.dataset.owner;
      const repo = btn.dataset.repo;
      const ir = await fetch(`/api/repos/${owner}/${repo}/issues`);
      if (!ir.ok) return alert('Failed to get issues');
      const issues = await ir.json();
      showIssuesModal(repo, issues);
    });
    container.appendChild(div);
  });
});

function showIssuesModal(repo, issues) {
  const list = issues.map(i => `<li><a href="${i.html_url}" target="_blank">${i.title}</a> <span class="small">#${i.number} by ${i.user?.login || ''}</span></li>`).join('');
  alert(`Issues for ${repo}:\n\n` + (list ? list.replace(/<[^>]+>/g,'') : 'No issues'));
}