package com.example.githubmanager.service;

import com.example.githubmanager.model.GitHubRepo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import java.util.*;

@Service
public class GitHubService {

    @Value("${github.token:}")
    private String githubToken;

    private static final String GITHUB_API = "https://api.github.com";

    public List<GitHubRepo> listUserRepos(String username) {
        String url = GITHUB_API + "/users/" + username + "/repos?per_page=100";
        RestTemplate rest = new RestTemplate();
        HttpEntity<String> entity = new HttpEntity<>(defaultHeaders());
        ResponseEntity<List> resp = rest.exchange(url, HttpMethod.GET, entity, List.class);

        List<Map<String,Object>> items = resp.getBody();
        List<GitHubRepo> repos = new ArrayList<>();
        if (items != null) {
            for (Map<String,Object> it : items) {
                String name = (String) it.get("name");
                String fullName = (String) it.get("full_name");
                String htmlUrl = (String) it.get("html_url");
                String desc = it.get("description") != null ? it.get("description").toString() : "";
                repos.add(new GitHubRepo(name, fullName, htmlUrl, desc));
            }
        }
        return repos;
    }

    public List<Map<String,Object>> listRepoIssues(String owner, String repo) {
        String url = GITHUB_API + "/repos/" + owner + "/" + repo + "/issues?per_page=100";
        RestTemplate rest = new RestTemplate();
        HttpEntity<String> entity = new HttpEntity<>(defaultHeaders());
        ResponseEntity<List> resp = rest.exchange(url, HttpMethod.GET, entity, List.class);
        return resp.getBody() != null ? resp.getBody() : Collections.emptyList();
    }

    private HttpHeaders defaultHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        if (githubToken != null && !githubToken.isBlank()) {
            headers.setBearerAuth(githubToken);
        }
        headers.set("User-Agent", "backend-github-manager");
        return headers;
    }
}