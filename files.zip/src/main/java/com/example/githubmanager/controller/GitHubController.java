package com.example.githubmanager.controller;

import com.example.githubmanager.model.GitHubRepo;
import com.example.githubmanager.service.GitHubService;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class GitHubController {

    private final GitHubService service;

    public GitHubController(GitHubService service) {
        this.service = service;
    }

    // List public repos for a username
    @GetMapping("/users/{username}/repos")
    public ResponseEntity<List<GitHubRepo>> listRepos(@PathVariable String username) {
        return ResponseEntity.ok(service.listUserRepos(username));
    }

    // List issues for owner/repo
    @GetMapping("/repos/{owner}/{repo}/issues")
    public ResponseEntity<List<Map<String,Object>>> listIssues(@PathVariable String owner, @PathVariable String repo) {
        return ResponseEntity.ok(service.listRepoIssues(owner, repo));
    }

    // Simple health endpoint
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("ok");
    }
}